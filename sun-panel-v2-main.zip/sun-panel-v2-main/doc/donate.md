> Open source development is not easy. If you feel that my project has been helpful to you, please feel free to buy me a cup of coffee ☕ (If possible, leave your nickname, name, or email in the note). Your support is my motivation. Thank you.

<a href="https://www.paypal.me/hslrs">
<img height="60" src="./images/donate/paypal.png" target="_blank"></img> 
</a>

|  WeChatPay | AliPay  |
| ------------ | ------------ |
| <img style="max-height:400px;box-shadow: 0 0 10px rgba(0,0,0,0.5);border-radius: 25px;" src="./images/donate/weixin.png"></img> |  <img style="max-height:400px;box-shadow: 0 0 10px rgba(0,0,0,0.5);border-radius: 25px;" src="./images/donate/alipay.png"></img> |