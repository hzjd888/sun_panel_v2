package adminApiStructs

type AboutSettingRequest struct {
	Content string `json:"content"`
}
