---
name: BUG
about: Using encountered bugs
title: "[BUG] Short description"
labels: bug
assignees: ''

---

**Version | 版本**
eg: v1.0.0

**Environment | 运行环境**
eg: docker / ubuntu / windows

**Detailed description | 详细说明**
...
