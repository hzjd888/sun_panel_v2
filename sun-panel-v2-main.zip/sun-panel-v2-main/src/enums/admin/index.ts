export enum AdminAuthRole {
  'admin' = 1, // 平台管理
  'regularUser' = 2, // 受限用户
}
