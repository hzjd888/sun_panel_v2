declare namespace AdminUserManage {
    interface GetListRequest{
        page:number
        limit:number
        keyWord?:string
    }
}